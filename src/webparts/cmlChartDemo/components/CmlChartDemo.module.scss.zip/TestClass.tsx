import * as React from 'react';
import { ICmlChartDemoProps } from './ICmlChartDemoProps';


export class TestClass extends React.Component<any, any> {
  render() {
    return (
      <div>
        
      </div>
    )
  }
}

export default TestClass
