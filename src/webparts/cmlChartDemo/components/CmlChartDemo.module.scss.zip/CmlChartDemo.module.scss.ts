/* tslint:disable */
require("./CmlChartDemo.module.css");
const styles = {
  cmlChartDemo: 'cmlChartDemo_24179295',
  container: 'container_24179295',
  row: 'row_24179295',
  column: 'column_24179295',
  'ms-Grid': 'ms-Grid_24179295',
  title: 'title_24179295',
  subTitle: 'subTitle_24179295',
  description: 'description_24179295',
  button: 'button_24179295',
  label: 'label_24179295'
};

export default styles;
/* tslint:enable */