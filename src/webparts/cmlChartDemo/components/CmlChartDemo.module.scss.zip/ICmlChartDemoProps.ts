import { IWebPartContext } from "@microsoft/sp-webpart-base";

export interface ICmlChartDemoProps {
  description: string;
  context: IWebPartContext;
}
